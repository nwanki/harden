#!/usr/bin/bash

set -e
sudo yum install -y ansible awscli
echo "CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05.tar"
cd /home/centos
pwd
ls -ltr
tar -xf CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05.tar
echo "Running build"
which ansible-playbook
sudo ansible-playbook --version
pwd
ls -ltr
echo "************************"
ls -ltr CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05
echo "************************"
sudo ansible-playbook CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05/main-site.yml
sudo yum remove -y ansible
rm -rf CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05 ~/CentOS7.6-v1.0.1-Docker-Gold-ENCRYPTED-Patched-2019-05-05.tar
