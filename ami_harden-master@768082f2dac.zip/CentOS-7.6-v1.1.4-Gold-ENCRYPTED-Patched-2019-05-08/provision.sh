#!/usr/bin/bash

set -e
sudo yum install -y ansible awscli
echo "Extracting CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08.tar"
cd /home/centos
pwd
ls -ltr
tar -xf CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08.tar
echo "Running build"
which ansible-playbook
sudo ansible-playbook --version
pwd
ls -ltr
echo "************************"
ls -ltr CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08
echo "************************"
sudo ansible-playbook CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08/main-site.yml
sudo yum remove -y ansible
rm -rf CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08 ~/CentOS-7.6-v1.1.4-Gold-ENCRYPTED-Patched-2019-05-08.tar
